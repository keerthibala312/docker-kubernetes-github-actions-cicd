# Docker + Kubernetes + GitHub Actions CI/CD

A simple DevOps project demonstrating a development-to-production workflow using Docker, Kubernetes and GitHub Actions.

## Architecture

Developer -> `dev` branch -> GitHub Actions -> Docker image -> GHCR -> Dev Kubernetes cluster

Developer -> Pull Request `dev` -> `main` -> Review/Approval -> GitHub Actions -> Docker image -> GHCR -> Production Kubernetes cluster

## Project requirements

- Docker
- Kubernetes cluster (Minikube, Kind, AKS, EKS, etc.)
- kubectl
- GitHub repository
- GitHub Container Registry (GHCR)

## 1. Run locally with Docker

```bash
docker build -t devops-demo:local .
docker run -p 5000:5000 -e APP_ENV=local devops-demo:local
```

Open `http://localhost:5000` and `http://localhost:5000/health`.

## 2. Create Kubernetes namespaces

```bash
kubectl apply -f k8s/namespaces.yaml
```

## 3. Test the development deployment

Replace `YOUR_GITHUB_USERNAME` in `k8s/dev/deployment.yaml` with your GitHub username, then:

```bash
kubectl apply -f k8s/dev/
kubectl -n dev get pods
kubectl -n dev get svc
kubectl -n dev port-forward svc/demo-app 8080:80
```

Open `http://localhost:8080`.

## 4. Git workflow

```bash
git checkout -b dev
git add .
git commit -m "Initial DevOps CI/CD project"
git push -u origin dev
```

The `dev.yml` workflow runs on pushes to `dev`.

For production:

1. Create a Pull Request from `dev` to `main`.
2. Require at least one reviewer.
3. Merge only after approval.
4. The `prod.yml` workflow runs after the approved merge to `main`.

## 5. GitHub Actions secrets

For each GitHub Environment (`development` and `production`) add:

- `KUBE_CONFIG` = base64 encoded kubeconfig for the target cluster.

Example:

```bash
base64 -w 0 ~/.kube/config
```

On macOS:

```bash
base64 ~/.kube/config | tr -d '\n'
```

Paste the result into the GitHub secret.

## 6. Important GitHub settings

Configure:

- `dev` branch: normal development branch.
- `main` branch: protect from direct pushes.
- Require pull request before merging.
- Require at least one approval.
- Optionally require successful GitHub Actions checks.
- Configure the `production` Environment with required reviewers if manual production approval is desired.

## 7. What this project demonstrates

- Docker image creation and containerization
- Kubernetes Deployments and Services
- Separate dev and prod namespaces/configuration
- GitHub Actions CI/CD
- GitHub Container Registry
- Automatic deployment to development after push to `dev`
- Pull request based promotion from `dev` to `main`
- Production deployment after approved merge
- Kubernetes health checks and resource limits
- Environment-specific variables

## Interview explanation

"I created a DevOps CI/CD project where the dev branch is used for development and main is protected for production. A push to dev triggers GitHub Actions, which validates the application, builds a Docker image, pushes it to GHCR and deploys the image to the development Kubernetes cluster. For production, changes are promoted through a pull request from dev to main. After review and approval, merging to main triggers a separate workflow that builds the production image and deploys it to the production Kubernetes cluster. I kept dev and prod isolated using separate Kubernetes namespaces and GitHub Environments."

## Note

This repository is a portfolio/demo implementation. Do not commit kubeconfig files, passwords, tokens or other secrets. Use GitHub Secrets/Environments for cluster credentials.

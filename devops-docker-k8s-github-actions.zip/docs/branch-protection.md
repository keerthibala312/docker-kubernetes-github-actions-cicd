# GitHub branch protection checklist

For the interview demo, configure these in GitHub:

### `main`
- Require a pull request before merging
- Require at least 1 approval
- Dismiss stale approvals when new commits are pushed (optional)
- Require status checks to pass (optional)
- Restrict direct pushes

### `dev`
- Allow normal development pushes
- Trigger the development workflow on push

### `production` Environment
- Add required reviewers if you want an approval gate before production deployment
- Add production `KUBE_CONFIG` secret

### development Environment
- Add development `KUBE_CONFIG` secret
